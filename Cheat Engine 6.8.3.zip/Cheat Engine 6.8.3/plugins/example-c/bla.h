/*
class weee {
  public:
	  int abc;

  private:
	  int bla;

};*/
